# Modules that need to be installed:
- tkinter
-- First, verify that pip is installed using `pip -v`
-- Install the tk module using `pip install tkinter`
# Instructions
1. Run `app.py`
2. Type the code in the text field at the upper left part of the program. Or you may upload a lolcode file.
3. Click the 'Execute' button.
4. The lexemes will be shown in the Lexeme or the second table. While the symbol table is shown in the third one.
4. Check the terminal at the bottom for the output of the program.
5. You may enter an input in the text field below the console once '>>' is shown on the console.
6. If you wish to clear the console, you may enter 'cls' in the text field below.