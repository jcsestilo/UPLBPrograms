import re

class Token(object):

    """""Contains token type, value, and position"""
    def __init__(self, type, val, pos):
        self.type = type
        self.val = val
        self.pos = pos

    def __str__(self) -> str:
        """ returns the string representation of the Token
            Lexeme + Classification
        """
        if self.type == "Line delimiter":
            return "Lexeme: \\n\t\tClassification: %s" % (self.type)
        return 'Lexeme: %s\t\tClassification: %s' % (self.val, self.type)


class Lexer(object):
    """
    Lexer: recognize reserved keywords from object input
    """
    def __init__(self, rules):
        """
        rules -> regex patterns used to match substrings and tokenize them
        """
        
        # All the regex-patterns declared in the 'rules' are concatenated via groups
        # The groups are named according to current index
        # Group names are then mapped according to their type (as specified in 'rules')
        # regex named groups info may be found here: https://docs.python.org/3/library/re.html
        
        index = 1
        regex_groups = []
        self.group_type = {}

        for regex, type in rules:
            group_name = 'GROUP%s' % index
            regex_groups.append('(?P<%s>%s)' % (group_name, regex))
            self.group_type[group_name] = type
            index += 1
       
        self.regex = re.compile('|'.join(regex_groups)) # concatenate all the parts (groups)
        self.re_ws_skip = re.compile('[^ \\t]')         # skips spaces and tabs
            

    def input(self, buffer):

        """initialize the input at position 0"""
        self.buffer = buffer
        self.pos = 0


    def token(self):
        """
        returns created Token object
        """
        
        if self.pos >= len(self.buffer): # return None if the end of buffer is reached
            return None
        else:

            m = self.re_ws_skip.search(self.buffer, self.pos) # search for a match in the buffer

            if m:
                self.pos = m.start() # set pos at index of start of the substring matched
            else: return None 

            # once found, match with pattern
            m = self.regex.match(self.buffer, self.pos) # match a pattern from the regex generated from the 'rules'
 
            # once matched, determine the group name and type
            # return the generated Token object 
            if m:
                groupname = m.lastgroup                         # get the name of the matched group
                token_type = self.group_type[groupname]         # get the group type using the group name
                if token_type == 'Error' : print("%s is an invalid lexeme." % m.group(0))
                tok = Token(token_type, m.group(groupname), self.pos)   # create Token object
                self.pos = m.end()                              # update pos
                return tok                                      # return token

            
             

    def tokens(self):

        # pag yield, generate  value tapos resume with the execution, so in this case, tutuloy yung while loop
        # https://www.geeksforgeeks.org/use-yield-keyword-instead-return-keyword-python/

        """generator function used to generate tokens"""
        while 1:
            tok = self.token()
            if tok is None: break
            yield tok               # generate token and continue to the next one
        
if __name__ == '__main__':
    
    # list of reserved keywords: (regex-pattern, classification)
    tokens_regex = [
        # KEYWORDS
        ('(?!<\w)HAI(?!\w)',            'Code Delimiter'),
        ('(?!<\w)KTHXBYE(?!\w)',        'Code Delimiter'),
        ('(?!<\w)BTW(?!\w)',            'Comment Delimiter'),
        ('(?!<\w)OBTW(?!\w)',           'Comment Delimiter'),
        ('(?!<\w)TLDR(?!\w)',           'Comment Delimiter'),
        ('(?!<\w)I HAS A(?!\w)',        'Variable Declaration'),
        ('(?!<\w)ITZ(?!\w)',            'Variable Assignment'),
        ('(?!<\w)R(?!\w)',              'Variable Assignment'),
        ('(?!<\w)SUM OF(?!\w)',         'Math Operator'),
        ('(?!<\w)DIFF OF(?!\w)',        'Math Operator'),
        ('(?!<\w)PRODUKT OF(?!\w)',     'Math Operator'),
        ('(?!<\w)QUOSHUNT OF(?!\w)',    'Math Operator'),
        ('(?!<\w)MOD OF(?!\w)',         'Math Operator'),
        ('(?!<\w)BIGGR OF(?!\w)',       'Math Operator'),
        ('(?!<\w)SMALLR OF(?!\w)',      'Math Operator'),
        ('(?!<\w)BOTH OF(?!\w)',        'Boolean Operator'),
        ('(?!<\w)EITHER OF(?!\w)',      'Boolean Operator'),
        ('(?!<\w)WON OF(?!\w)',         'Boolean Operator'),
        ('(?!<\w)NOT(?!\w)',            'Boolean Operator'),
        ('(?!<\w)ANY OF(?!\w)',         'Boolean Operator'),
        ('(?!<\w)ALL OF(?!\w)',         'Boolean Operator'),
        ('(?!<\w)BOTH SAEM(?!\w)',      'Comparison Operator'),
        ('(?!<\w)DIFFRINT(?!\w)',       'Comparison Operator'),
        ('(?!<\w)SMOOSH(?!\w)',         'Concatenator'),
        ('(?!<\w)MAEK(?!\w)',           'Typecast Operator'),
        ('(?!<\w)A(?!\w)',              'Reserved [A] keyword'),
        ('(?!<\w)IS NOW A(?!\w)',       'Typecast Operator'),
        ('(?!<\w)VISIBLE(?!\w)',        'Output Keyword'),
        ('(?!<\w)GIMMEH(?!\w)',         'Input Keyword'),
        ('(?!<\w)O RLY\?(?!\w)',        'If-then Statement'),
        ('(?!<\w)YA RLY(?!\w)',         'If-then Statement'),
        ('(?!<\w)MEBBE(?!\w)',          'If-then Statement'),
        ('(?!<\w)NO WAI(?!\w)',         'If-then Statement'),
        ('(?!<\w)OIC(?!\w)',            'If-then Statement'),
        ('(?!<\w)WTF(?!\w)',            'Switch-case'),
        ('(?!<\w)OMG(?!\w)',            'Switch-Case'),
        ('(?!<\w)OMGWTF(?!\w)',         'Switch-Case'),
        ('(?!<\w)IM IN YR(?!\w)',       'Loop'),
        ('(?!<\w)UPPIN(?!\w)',          'Increment Operator'),
        ('(?!<\w)NERFIN(?!\w)',         'Decrement Operator'),
        ('(?!<\w)YR(?!\w)',             'Loop'),
        ('(?!<\w)TIL(?!\w)',            'Loop'),
        ('(?!<\w)WILE(?!\w)',           'Code Delimiter'),
        ('(?!<\w)IM OUTTA YR(?!\w)',    'Code Delimiter'),

        # ADDED LEXEMES/KEYWORDS (from req 02)
        ('(?!<\w)AN(?!\w)',             'Argument Delimiter'),
        ('(?!<\w)I IZ(?!\w)',           'Function Caller'),
        ('(?!<\w)MKAY(?!\w)',           'Argument Delimiter'),
        ('(?!<\w)FOUND YR(?!\w)',       'Function Return'),
        ('(?!<\w)GTFO(?!\w)',           'Function Return'),
        ('(?!<\w)HOW IZ I(?!\w)',       'Function Definition'),
        ('(?!<\w)IF U SAY SO(?!\w)',    'Function Definition'),
        ('(\\n)',                       'Line delimiter'),

        # LITERALS
        ('(?!<\w)(-[0-9]*\.[0-9]+|[0-9]+\.[0-9]+)(?!\w)',                   'NUMBAR Literal'),
        ('(?!<\w)(0|(-?[1-9][0-9]*))(?!\w)',                                'NUMBR Literal'),
        ('(?!<\w)((WIN)|(FAIL))(?!\w)',                                     'TROOF Literal'),
        ('(?!<\w)((TROOF)|(NOOB)|(NUMBR)|(NUMBAR)|(YARN)|(TYPE))(?!\w)',    'TYPE Literal'),
        ('(?!<\w)\\"(:\\"|[^\\"])*\\"(?!\w)',                               'YARN Literal'),

        # IDENTIFIERS
        ('[a-zA-Z][a-zA-Z0-9_]*',                                           'Variable Identifier'),
        ('[a-zA-Z][a-zA-Z0-9_]*',                                           'Function Identifier'),
        ('[a-zA-Z][a-zA-Z0-9_]*',                                           'Loop Identifier'),
        ('.*',                                                              'Error')
        ]

    
    lx = Lexer(tokens_regex)
    
    # sample string input
    str = """       
    HAI
        I HAS A your_name
        GIMMEH your_name
        SMOOSH "Hello " AN your_name MKAY
        I HAS A result
        MAEK result A YARN
        result R "Sum: "
        I HAS A numbah ITZ 10
        I HAS A numbah1
        numbah1 R 15
        I HAS A sum ITZ SUM OF numbah AN numbah1
        VISIBLE SMOOSH result AN sum
        _asd
        KTHXBYE
    """
    
    print(str)
    lines = [] # list for tokens

    # multi-line input loop
    # asks for user input until an 'empty' line is entered
    # while True:
    #     user_input = input()

    #     if user_input == 'exit':
    #         break
    #     else: lines.append(user_input + '\n')

    lx.input(''.join(lines)) # converted list to string since the lexer accepts string input
    lx.input(str) 

    for tok in lx.tokens():
        if tok.type != "Error":
            print(tok)


# ADDITIONAL REFERENCES
# https://gist.github.com/eliben/5797351
# https://docs.python.org/3/library/re.html#re.search